ti-widget-readme
=======================

This component displays the README.md file in the application folder.

